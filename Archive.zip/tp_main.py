from cmu_112_graphics import *
from tp_ghosts import *
from pellets import *
from movePacman import *
from pauseGameOverhasWon import *
from classAndAppStarted import *
from distanceBoundsLegal import *
from draw import *

# appStarted, keyPressed, timerFired, redrawAll are all from cmu_112_graphics
# citation link: https://www.cs.cmu.edu/~112/notes/notes-graphics.html

def keyPressed(app, event):
    pause(app, event)
    if app.isGameOver or app.hasWon or app.paused:
        return
    changePacManDir(app, event)

def timerFired(app):
    app.timerDelay = 200
    isGameOver(app)
    hasWon(app)
    if app.isGameOver or app.hasWon or app.paused:
        return
    app.ghostMoveTimer += 1
    if app.ghostMoveTimer == 2:
        app.ghostMoveTimer = 0
        changeBlinkyTarget(app)
        changePinkyTarget(app)
        changeInkyTarget(app)
        changeClydeTarget(app)
        changeGhostDirsTowardsTarget(app)
        moveGhosts(app)
        eatPacMan(app)
    spawnGhosts(app)
    movePacMan(app)
    eatPacMan(app)
    eatPellet(app)
    eatPowerPellet(app)
    eatTrickPellet(app)
    frightenedTimer(app)


def redrawAll(app, canvas):  
    drawBoard(app, canvas)
    drawPacMan(app, canvas)
    drawGhosts(app, canvas)
    drawLives(app, canvas)
    drawScore(app, canvas)
    drawPauseMsg(app, canvas)
    drawGameOverMsg(app, canvas)
    drawVictoryMsg(app, canvas)



runApp(width = 400, height = 400)


