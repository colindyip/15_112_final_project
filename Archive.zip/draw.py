from cmu_112_graphics import *
from distanceBoundsLegal import *

# from CMU 15112 Tetris For Intro/Intermediate Programmers
# link: https://www.cs.cmu.edu/~112/notes/notes-tetris/2_2_CreatingTheBoard.html
def drawCell(app, canvas, row, col, color):
    (x1,y1,x2,y2) = getCellBounds(app, row, col)
    canvas.create_rectangle(x1,y1,x2,y2,fill=color)

def drawPacMan(app, canvas):
    (cellx1,celly1,cellx2,celly2) = getCellBounds(app, app.PacManRow, app.PacManCol)
    pacManMargin = 2
    canvas.create_oval(cellx1+pacManMargin,celly1+pacManMargin,
                        cellx2-pacManMargin,celly2-pacManMargin, fill = 'yellow')


def drawGhosts(app, canvas):
    ghostColors = ['red','pink','orange','cyan']
    for i in range(len(app.ghosts)):
        currGhost = app.ghosts[i]
        if app.ghostMode == 'chase':
            color = ghostColors[i]
        else:
            color = 'light blue'
        (x1,y1,x2,y2) = getCellBounds(app, currGhost.row, currGhost.col)
        margin = 3
        canvas.create_rectangle(x1+margin,y1+margin,x2-margin,y2-margin,fill = color)

def drawBoard(app, canvas):
    for row in range(app.numRows):
        for col in range(app.numCols):
            # space
            if app.map[row][col] == 'space':
                if app.mapMode == 'normal':
                    color = 'black'
                    drawCell(app, canvas, row, col, color)
            # wall
            elif app.map[row][col] == 'wall':
                if app.mapMode == 'normal':
                    color = 'blue'
                    drawCell(app, canvas, row, col, color)
            # pellet
            elif app.map[row][col] == 'pellet':
                if app.mapMode == 'normal':
                    color = 'black'
                    drawCell(app, canvas, row, col, color)
                (x1, y1, x2, y2) = getCellBounds(app, row, col)
                (cx, cy) = ((x1 + x2) // 2, (y1 + y2) // 2)
                r = 2 
                canvas.create_oval(cx - r, cy - r, cx + r, cy + r,
                                    fill = 'orange')
            # power pellet
            else:
                # cell containing power pellet
                if app.mapMode == 'normal':
                    color = 'black'
                    drawCell(app, canvas, row, col, color)
                # power pellet as circle
                (x1, y1, x2, y2) = getCellBounds(app, row, col)
                (cx, cy) = ((x1 + x2) // 2, (y1 + y2) // 2)
                r = 4 
                canvas.create_oval(cx - r, cy - r, cx + r, cy + r,
                                    fill = 'orange')

def drawLives(app, canvas):
    canvas.create_text(app.width-5, app.height-5, anchor = 'se', 
                        text = f'Lives = {app.PacManLives}',
                        font = 'Arial 18 bold', fill = 'black')

def drawPauseMsg(app, canvas):
    if app.paused and not app.isGameOver:
        canvas.create_text(app.width // 2, app.height // 2, 
                        font = 'Arial 32 bold', fill = 'light green',
                        text = 'Press Space Bar \nto Resume the Game')

def drawGameOverMsg(app, canvas):
    if app.isGameOver:
        canvas.create_text(app.width // 2, app.height // 2, 
                        font = 'Arial 32 bold', fill = 'light green',
                        text = 'Game Over!')


def drawVictoryMsg(app, canvas):
    if app.hasWon:
        canvas.create_text(app.width // 2, app.height // 2, 
                        font = 'Arial 32 bold', fill = 'light green',
                        text = 'Victory!')

def drawScore(app, canvas):
    canvas.create_text(app.width // 2, app.height - 15, 
                        font = 'Arial 18 bold', fill = 'black',
                        text = f'Score = {app.score}')