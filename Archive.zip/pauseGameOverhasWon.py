from cmu_112_graphics import *

def isGameOver(app):
    if app.PacManLives == 0:
        app.isGameOver = True


def hasWon(app):
    numTotalPellets = 183
    if app.pelletsEaten == numTotalPellets:
        app.hasWon = True

def pause(app, event):
    if event.key == 'Space':
        app.paused = not app.paused