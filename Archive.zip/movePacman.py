from cmu_112_graphics import *
from distanceBoundsLegal import *

# changes direction of pacman based on arrow key pressed
def changePacManDir(app, event):
    originaldx, originaldy = app.PacManDx, app.PacManDy
    if event.key == 'Left':
        app.PacManDx = -1
        app.PacManDy = 0
    elif event.key == 'Right':
        app.PacManDx = 1
        app.PacManDy = 0
    elif event.key == 'Up':
        app.PacManDx = 0
        app.PacManDy = -1
    elif event.key == 'Down':
        app.PacManDx = 0
        app.PacManDy = 1
    newRow, newCol = app.PacManRow + app.PacManDy, app.PacManCol + app.PacManDx
    if not isLegalPos(app, newRow, newCol):
            app.PacManDx, app.PacManDy = originaldx, originaldy

# moves pacman using timer
def movePacMan(app):
    app.PacManRow += app.PacManDy
    app.PacManCol += app.PacManDx
    # wraparound
    if app.PacManCol < 0 or app.PacManCol >= app.numCols:
        app.PacManCol %= app.numCols
    # if the move would send pacMan into a wall, undo the move
    if not isLegalPos(app, app.PacManRow, app.PacManCol):
        app.PacManRow -= app.PacManDy
        app.PacManCol -= app.PacManDx
