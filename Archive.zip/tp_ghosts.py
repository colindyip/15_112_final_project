from cmu_112_graphics import *
from distanceBoundsLegal import *
from classAndAppStarted import *

def changeBlinkyTarget(app):
    blinky = app.ghosts[0]
    if app.ghostMode == 'chase':
        (blinky.targetRow, blinky.targetCol) = (app.PacManRow, app.PacManCol)
    else:
        topLeft = (1,2)
        (blinky.targetRow, blinky.targetCol) = topLeft

def changePinkyTarget(app):
    pinky = app.ghosts[1]
    if app.ghostMode == 'chase':
        (pinky.targetRow, pinky.targetCol) = (app.PacManRow + 2*app.PacManDy,
                                                app.PacManCol + 2*app.PacManDx)
    else:
        topRight = (1, 19)
        (pinky.targetRow, pinky.targetCol) = topRight

def changeInkyTarget(app):
    if len(app.ghosts) >= 3:
        blinky = app.ghosts[0]
        pinky = app.ghosts[1]
        inky = app.ghosts[2]
        if app.ghostMode == 'chase':
            blinkyToPinkyTargetDx, blinkyToPinkyTargetDy = (pinky.targetCol - blinky.col, 
                                                pinky.targetRow - blinky.row)
            (inky.targetRow, inky.targetCol) = (blinky.row + 2*blinkyToPinkyTargetDy,
                                            blinky.col + 2*blinkyToPinkyTargetDx)
        else:
            bottomLeft = (20,2)
            (inky.targetRow, inky.targetCol) = bottomLeft

def changeClydeTarget(app):
    if len(app.ghosts) >= 4:
        blinky = app.ghosts[0]
        clyde = app.ghosts[3]
        if app.ghostMode == 'chase':
            colWidth = (app.width - 2*app.margin) // app.numCols
            eightTileDistance = colWidth * 8
            (clydex1, clydey1, _, _) = getCellBounds(app, clyde.row, clyde.col)
            (pacManx1, pacMany1, _, _) = getCellBounds(app, app.PacManRow, app.PacManCol)
            if distance(clydex1, clydey1, pacManx1, pacMany1) > eightTileDistance:
                (clyde.targetRow, clyde.targetCol) = (blinky.targetRow, blinky.targetCol)
            else:
                (clyde.targetRow, clyde.targetCol) = (20, 2)
        else:
            bottomRight = (20,19)
            (clyde.targetRow, clyde.targetCol) = bottomRight

def changeGhostDirsTowardsTarget(app):
    for ghost in app.ghosts:
        possibleDirs = [(1,0),(0,1),(-1,0),(0,-1)]
        oppOfOriginalDir = (-ghost.dx, -ghost.dy)
        (targetx1, targety1, _, _) = getCellBounds(app, ghost.targetRow, ghost.targetCol)
        if ghost.isAtIntersection(app):
            bestDir = None
            bestDistance = None
            for dir in possibleDirs:
                if dir != oppOfOriginalDir:
                    (dx,dy) = dir
                    (newGhostRow, newGhostCol) = ((ghost.row + dy) % app.numRows, 
                                                    (ghost.col + dx) % app.numCols)
                    if isLegalPos(app, newGhostRow, newGhostCol):
                        (newGhostx1, newGhosty1, _, _) = getCellBounds(app, newGhostRow, newGhostCol)
                        newDistanceFromPacMan = distance(newGhostx1, newGhosty1, targetx1, targety1)
                        if bestDistance == None or newDistanceFromPacMan < bestDistance:
                            bestDir = dir
                            bestDistance = newDistanceFromPacMan
            (ghost.dx, ghost.dy) = bestDir
    
    
# first, get blinky to move in dir of pacMan
# then make it so that blinky can't change dir until he hits wall
def moveGhosts(app):
    for ghost in app.ghosts:
        ghost.row += ghost.dy
        ghost.col += ghost.dx
        # wraparound
        if ghost.col < 0 or ghost.col >= app.numCols:
            ghost.col %= app.numCols
                # if the move would send pacMan into a wall, undo the move
        if not isLegalPos(app, ghost.row, ghost.col):
            ghost.row -= ghost.dy
            ghost.col -= ghost.dx

def eatPacMan(app):
    for ghost in app.ghosts:
        if ghost.row == app.PacManRow and ghost.col == app.PacManCol:
            if app.ghostMode == 'chase':
                app.PacManLives -= 1
                (app.PacManRow, app.PacManCol) = (1,2)
                (app.PacManDx, app.PacManDy) = (0,0)
                for ghost in app.ghosts:
                    (ghost.row, ghost.col) = (7,10)
                    (ghost.dx, ghost.dy) = (-1,0)
                app.paused = True
            elif app.ghostMode == 'frightened':
                (ghost.row, ghost.col) = (9,10)
                (ghost.dx, ghost.dy) = (0,0)
                app.score += 200

def spawnGhosts(app):
    if len(app.ghosts) == 4:
        return
    numSecsInBetweenSpawns = 5
    timerFiredsPerSec = 5
    numTimerFiredsBetweenSpawns = numSecsInBetweenSpawns * timerFiredsPerSec
    app.ghostSpawnTimer += 1
    if app.ghostSpawnTimer == numTimerFiredsBetweenSpawns:
        app.ghostSpawnTimer = 0
        newGhostIndex = len(app.ghosts)
        newGhost = app.allGhosts[newGhostIndex]
        app.ghosts.append(newGhost)