from cmu_112_graphics import *

def distance(x1,y1,x2,y2):
    return ((x2-x1)**2 + (y2-y1)**2)**0.5

# from CMU 15112 website
# link: https://www.cs.cmu.edu/~112/notes/notes-animations-part2.html
def getCellBounds(app, row, col):
    rowWidth = (app.height - 2*app.margin) // app.numRows
    colWidth = (app.width - 2*app.margin) // app.numCols
    x1 = app.margin + col*colWidth
    y1 = app.margin + row*rowWidth
    x2 = app.margin + (col+1)*colWidth
    y2 = app.margin + (row+1)*rowWidth
    return (x1,y1,x2,y2)

# pacMan's position is legal if and only if it is not a wall
def isLegalPos(app, row, col):
    return not app.map[row][col] == 'wall'