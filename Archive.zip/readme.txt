﻿Project Description:


The project will be called “Pac-Man 2”. Similar to the original version of Pac-Man, the user controls Pac-Man. Pac-Man eats pellets by passing through the tiles pellets are on, and the user wins the game if Pac-Man eats all of the pellets. Four ghosts move around the board and if any of them hit Pac-Man, Pac-Man loses a life. If Pac-Man runs out of lives, the user loses the game. One difference between Pac-Man 2 and Pac-Man is that Pac-Man 2 has an additional powerup (the “Trick Pellet” which temporarily makes the maze invisible) and Pac-Man 2 only contains one level.


How to Run the Project:


Download all the files included in the zip file. Run the file “tp_main.py” in an editor.


Libraries:


The only library that must be installed is “cmu_112_graphics.py”. This is included in the zip file.


Shortcut Commands:


There are no shortcut commands.