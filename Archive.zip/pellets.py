from cmu_112_graphics import *


def eatPellet(app):
    (row, col) = (app.PacManRow, app.PacManCol)
    if app.map[row][col] == 'pellet':
        app.pelletsEaten += 1
        app.map[row][col] = 'space'

# power pellets turn the ghost mode to 'frightened'
def eatPowerPellet(app):
    (row, col) = (app.PacManRow, app.PacManCol)
    if app.map[row][col] == 'Power Pellet':
        app.ghostMode = 'frightened'
        app.map[row][col] = 'space'
        app.frightenedTimer = 0
        for ghost in app.ghosts:
            (ghost.dx, ghost.dy) = (-ghost.dx, -ghost.dy)

def eatTrickPellet(app):
    (row, col) = (app.PacManRow, app.PacManCol)
    if app.map[row][col] == 'trick pellet':
        app.mapMode = 'invisible'
        app.map[row][col] = 'space'

def frightenedTimer(app):
    if app.ghostMode == 'frightened':
        app.frightenedTimer += 1
    if app.frightenedTimer == 50:
        app.frightenedTimer = 0
        app.ghostMode = 'chase'
        for ghost in app.ghosts:
            if (ghost.dx, ghost.dy) == (0,0):
                (ghost.dx, ghost.dy) = (-1,0)
                (ghost.row, ghost.col) = (7,10)