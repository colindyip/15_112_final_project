from cmu_112_graphics import *

def appStarted(app):
    # creates the map, 0 means space, 1 means wall
    app.map = [['space','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','Power Pellet','pellet','pellet','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','Power Pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','wall','wall','wall','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','wall','wall','space'],
            ['pellet','pellet','pellet','pellet','wall','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','wall','pellet','pellet','pellet','pellet'],
            ['wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall'],
            ['pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet'],
            ['wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall'],
            ['pellet','pellet','pellet','pellet','wall','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','wall','pellet','pellet','pellet','pellet'],
            ['space','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','pellet','wall','space'],
            ['space','wall','Power Pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','Power Pellet','wall','space'],
            ['space','wall','wall','pellet','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','pellet','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','wall','pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','space']]
    app.numRows = len(app.map)
    app.numCols = len(app.map[0])
    app.margin = 15
    (app.PacManRow, app.PacManCol) = (1,2)
    app.PacManDx = 0
    app.PacManDy = 0
    app.blinky = Ghost(7, 10, -1, 0)
    app.ghosts = [app.blinky]
    app.ghostMode = 'chase'
    app.PacManLives = 3
    app.isGameOver = False
    app.hasWon = False
    app.pelletsEaten = 0
    app.score = 0
    app.paused = False
    #(app.blinkyRow, app.blinkyCol) = (7,10)
    #(app.blinkyDx, app.blinkyDy) = (0,0)

def eatPellet(app):
    (row, col) = (app.PacManRow, app.PacManCol)
    if app.map[row][col] == 'pellet':
        app.pelletsEaten += 1
        app.map[row][col] = 'space'

# power pellets turn the ghost mode to 'frightened'
def eatPowerPellet(app):
    (row, col) = (app.PacManRow, app.PacManCol)
    if app.map[row][col] == 'Power Pellet':
        app.ghostMode = 'frightened'
        app.map[row][col] = 'space'