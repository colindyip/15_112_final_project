from cmu_112_graphics import *

class Ghost:
    def __init__(self, row, col, dx, dy):
        self.row, self.col = row, col
        self.dx, self.dy = dx, dy
        self.targetRow, self.targetCol = 1, 2
    def isAtIntersection(self, app):
        # if character can move in at least three directions, it is at an intersection
        combinations = [((1,0),(0,1)),((0,1),(-1,0)),((-1,0),(0,-1)),((0,-1),(1,0))]
        for combination in combinations:
            ((dx1, dy1),(dx2,dy2)) = combination
            (newRow1, newCol1, newRow2, newCol2) = (self.row + dy1, (self.col + dx1) % app.numCols, self.row + dy2, (self.col + dx2) % app.numCols)
            if app.map[newRow1][newCol1] != 'wall' and app.map[newRow2][newCol2] != 'wall':
                return True
        return False

def appStarted(app):
    # creates the map, 0 means space, 1 means wall
    app.map = [['space','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','Power Pellet','wall','wall','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','trick pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','wall','wall','wall','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','wall','wall','space'],
            ['space','space','space','space','wall','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','wall','space','space','space','space'],
            ['wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall'],
            ['pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space','space','space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet'],
            ['wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall'],
            ['space','space','space','space','wall','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','wall','space','space','space','space'],
            ['space','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','pellet','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','pellet','wall','wall','pellet','wall','space'],
            ['space','wall','Power Pellet','pellet','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','pellet','Power Pellet','wall','space'],
            ['space','wall','wall','pellet','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','pellet','wall','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','wall','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','pellet','wall','wall','wall','wall','wall','wall','pellet','wall','pellet','wall','wall','wall','wall','wall','wall','pellet','wall','space'],
            ['space','wall','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','pellet','wall','space'],
            ['space','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','wall','space']]
    app.numRows = len(app.map)
    app.numCols = len(app.map[0])
    app.margin = 15
    app.mapMode = 'normal'
    (app.PacManRow, app.PacManCol) = (1,2)
    app.PacManDx = 0
    app.PacManDy = 0
    app.blinky = Ghost(7,10,-1,0)
    app.pinky = Ghost(7,10,1,0)
    app.inky = Ghost(7,10,1,0)
    app.clyde = Ghost(7,10,-1,0)
    app.allGhosts = [app.blinky, app.pinky, app.inky, app.clyde]
    app.ghosts = [app.blinky, app.pinky]
    app.ghostMode = 'chase'
    app.ghostMoveTimer = 0
    app.ghostSpawnTimer = 0
    app.frightenedTimer = 0
    app.PacManLives = 3
    app.isGameOver = False
    app.hasWon = False
    app.pelletsEaten = 0
    app.score = 0
    app.paused = True
    #(app.blinkyRow, app.blinkyCol) = (7,10)
    #(app.blinkyDx, app.blinkyDy) = (0,0)